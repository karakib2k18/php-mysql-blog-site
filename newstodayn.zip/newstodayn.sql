-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 08, 2021 at 11:31 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newstodayn`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(20) NOT NULL,
  `c_desc` varchar(255) NOT NULL,
  `c_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`, `c_desc`, `c_status`) VALUES
(3, 'sports ', 'sports catagory', 1),
(5, 'football ', 'I love football', 1),
(22, 'cricket ', 'cricket category', 1),
(27, 'dfsadfsadf', 'dfsfasfas', 0),
(32, 'lifestyle', 'superstart', 1),
(33, 'Student', 'Student of the year', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `cmnt_id` int(11) NOT NULL,
  `cmnt_author` int(11) NOT NULL,
  `cmnt_desc` text NOT NULL,
  `cmnt_date` date NOT NULL,
  `cmnt_post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cmnt_id`, `cmnt_author`, `cmnt_desc`, `cmnt_date`, `cmnt_post`) VALUES
(1, 2, 'Bagram1 also contains a prison, and there are reportedly up to 5,000 Taliban prisoners left in the facility.', '2021-07-06', 1),
(2, 43, 'Bagram2 also contains a prison, and there are reportedly up to 5,000 Taliban prisoners left in the facility.', '2021-07-06', 2),
(3, 2, 'Bagram3 also contains a prison, and there are reportedly up to 5,000 Taliban prisoners left in the facility.', '2021-07-06', 2),
(4, 43, 'Bagram4 also contains a prison, and there are reportedly up to 5,000 Taliban prisoners left in the facility.', '2021-07-06', 2);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `p_id` int(11) NOT NULL,
  `p_title` varchar(255) NOT NULL,
  `p_image` varchar(255) NOT NULL,
  `p_author` int(11) NOT NULL,
  `p_description` text NOT NULL,
  `p_date` date NOT NULL,
  `p_cat` int(11) NOT NULL,
  `p_comment` varchar(200) NOT NULL,
  `p_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`p_id`, `p_title`, `p_image`, `p_author`, `p_description`, `p_date`, `p_cat`, `p_comment`, `p_status`) VALUES
(1, 'China administers a billion vaccine doses1', 'rakib.jpg', 2, 'After lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.', '2021-06-08', 3, '', 1),
(2, 'China administers a billion vaccine doses2', 'rakib2.jpg', 43, 'After lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.', '2021-06-09', 5, '', 0),
(10, 'China administers a billion vaccine doses3', '817490116rakib 192kb.jpg', 65, 'After3 lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.', '2021-07-02', 5, '', 1),
(11, 'China administers a billion vaccine doses4', '1904605347rakib short.jpg', 65, 'After lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.', '2021-07-02', 5, '', 1),
(12, 'China administers a billion vaccine doses5', '1895963767photoshop.png', 65, 'After lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and  National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.\r\n\r\nAfter lockdowns and mass testing prevented the virus from circulating, many Chinese felt little need to get vaccinated. Previous vaccine scandals had also left some people wary.\r\n\r\nHowever the pace of vaccinations has rapidly increased and National Health Commission said it had taken just five days to administer the latest 100 million doses.\r\n\r\nAn outbreak of the Delta variant in the southern province of Guangdong has also convinced some Chinese to be vaccinated.', '2021-07-04', 33, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `u_name` varchar(255) NOT NULL,
  `u_image` varchar(255) DEFAULT NULL,
  `u_email` varchar(255) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `u_address` varchar(255) DEFAULT NULL,
  `u_phone` int(11) DEFAULT NULL,
  `u_dob` date DEFAULT NULL,
  `u_gender` varchar(10) DEFAULT NULL,
  `u_bio` text DEFAULT NULL,
  `u_education` text DEFAULT NULL,
  `u_role` int(11) DEFAULT NULL,
  `u_status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `u_name`, `u_image`, `u_email`, `u_password`, `u_address`, `u_phone`, `u_dob`, `u_gender`, `u_bio`, `u_education`, `u_role`, `u_status`) VALUES
(2, 'alina2', 'alina.jpg', 'alina@gmail.com', '123456', 'Cumilla, Bangladesh', 374671435, '2000-01-01', 'Female', 'lorem ipsum2', 'lorem ipsum2', 1, 1),
(43, 'alina43', 'RAKIB.jpg', 'alina@gmail.com', '9ddd9070de73fa72bc55812892e9d78f9aed3360', 'Cumilla, Bangladesh43', 374671435, '2000-01-01', 'Male', 'lorem ipsum43', 'lorem ipsu43', 2, 1),
(63, 'alina63', '20414852963.jpg', 'alina@gmail.com', '', 'Cumilla, Bangladesh', 374671435, '2000-01-01', 'Female', 'lorem ipsum2', 'lorem ipsum2', 1, 1),
(65, 'RAKIB1', '469587254resize-16231642831959951066rayhan.jpg', 'RAKIB@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'sadfasdfa', 123123434, '2021-06-22', 'Male', 'dfgsdfgdsfg', 'sdfgdsfg', 0, 0),
(66, 'NEW', '1924463359RAKIB AHUT.jpg', 'RAKIB@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'NEW111', 273467824, '2021-06-15', 'Female', 'NEW', 'NEW111', 1, 1),
(73, 'admin', 'admin.jpg', 'admin@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'ADMIN HOUSE, DHAKA', 1864466543, '2021-06-08', 'Male', 'I\'m an Admin.....', 'Student', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`cmnt_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `cmnt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
